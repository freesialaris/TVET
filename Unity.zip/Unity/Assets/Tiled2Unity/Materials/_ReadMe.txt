Material directory

Tiled2Unity scripts will create materials here. These materials are referenced 
by the meshes that represent your Tiled Map Editor layers.